# Prompt: "يوميتي" — private daily journal (faith-centered)

You are a senior Android/product engineer. Evolve the attached `index.html` (working v0.1, vanilla JS, localStorage) into a polished, installable app. Target: Android 15 phones, Arabic (Egyptian tone) RTL-first, offline-first, private (no accounts, no servers, no analytics).

## Product
A personal daily journal with a morning/evening rhythm plus a long-term library.
- Daily page: verse of the day, 3 "do" and 3 "don't" items, personal prayer, my promise to God, God's promise to me, evening check (kept / partly / not kept, no guilt), 3 thanks, note.
- Library: dreams, fears, wishes, taboos, life goals each with obstacles, smallest next step, and a linked verse.
- History: promises kept over time, answered prayers.

## Roadmap (do one phase per commit, keep app runnable)
1. Refactor to Vite + TypeScript + Preact/React, IndexedDB (Dexie) with a versioned schema and migration from v0.1 localStorage JSON.
2. Bundle a public-domain Arabic Bible (Van Dyck) as an offline SQLite/JSON asset; verse picker (book/chapter/verse), search, reading plan, "save verse" to a personal list.
3. Link each fear to a verse/promise; link obstacles to goals; show the pairing on the day page when relevant.
4. Prayer archive: open / answered (date + note). Promise ledger: counts and a gentle monthly view.
5. Weekly and monthly review screen: patterns in "don'ts", moved goals, thanks highlights.
6. Security: PIN + biometric (WebAuthn), auto-lock, AES-GCM encrypted export/import, optional Drive/GitHub backup of the encrypted file only.
7. PWA (manifest, service worker) and Capacitor Android wrapper; GitHub Actions workflow that builds a signed APK/AAB.

## Rules
- Soft, quiet design; large touch targets; dark mode; respects reduced motion; accessible contrast.
- Never shame the user: wording around missed promises stays gentle.
- Max 2 reminders/day (morning, evening) via local notifications.
- All data stays on device; export is user-initiated.
- Tests for storage, migration, and export/import round-trip.

## Deliver each phase with
Short changelog, what to test on a real phone, and the next phase's risks.
