# يوميتي
React + TypeScript + Vite + Dexie (IndexedDB). Offline, private, RTL.
- `npm i && npm run dev` to run, `npm run build` to check.
- Push to GitHub: the Actions workflow builds a debug APK (Capacitor) as an artifact.
- Development plan and AI Studio prompt: `PLAN_PROMPT.md` (phases 1 and 2 are done: typed project + offline Arabic Van Dyck Bible, public domain, from midvash/bible-data).

## Release signing (optional)
Create a keystore once: `keytool -genkeypair -v -keystore yawmiyati.jks -alias yawmiyati -keyalg RSA -keysize 2048 -validity 10000`
Then add repository secrets: `KEYSTORE_B64` (`base64 -w0 yawmiyati.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Keep the keystore backed up: losing it means you cannot update the installed app.
Native biometrics (@aparajita/capacitor-biometric-auth) and daily reminders (@capacitor/local-notifications) work only inside the APK; the PWA uses WebAuthn and has no reminders.
