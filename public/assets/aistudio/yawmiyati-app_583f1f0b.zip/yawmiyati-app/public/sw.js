const C='yawmiyati-v1'
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(['./','index.html','manifest.webmanifest','icon.svg','bible-svd.json'])))})
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()))
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return
if(r.mode==='navigate'){e.respondWith(fetch(r).catch(()=>caches.match('index.html')));return}
e.respondWith(caches.match(r).then(h=>h||fetch(r).then(n=>{if(n.ok&&new URL(r.url).origin===location.origin){const k=n.clone();caches.open(C).then(c=>c.put(r,k))}return n})))})
