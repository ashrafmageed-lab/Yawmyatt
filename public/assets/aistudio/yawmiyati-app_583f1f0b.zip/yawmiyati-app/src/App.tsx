import{useState,useRef,useEffect}from'react'
import{saveFile}from'./files'
import{native,getRem,applyRem}from'./reminders'
import{bioSupported,bioOn,bioOff,bioEnroll,bioCheck}from'./bio'
import BiblePicker from'./BiblePicker'
import{useLiveQuery}from'dexie-react-hooks'
import{db,today,emptyDay,sha,exportAll,importAll,Day,Item,Kind,Entry}from'./db'
type TextKey='ref'|'verse'|'prayer'|'toGod'|'fromGod'|'thanks'|'note'
const PIN='yawmiyati.pin'
function Add({ph,on}:{ph:string;on:(t:string)=>void}){const[v,setV]=useState('');const go=()=>{if(v.trim()){on(v.trim());setV('')}}
return<div className="row"><input value={v} placeholder={ph} onChange={e=>setV(e.target.value)} onKeyDown={e=>e.key==='Enter'&&go()}/><button onClick={go}>إضافة</button></div>}
function Txt({label,k,day,put,one}:{label:string;k:TextKey;day:Day;put:(p:Partial<Day>)=>void;one?:boolean}){const[v,setV]=useState(day[k])
const save=()=>put({[k]:v})
return<label>{label}{one?<input value={v} onChange={e=>setV(e.target.value)} onBlur={save}/>:<textarea value={v} onChange={e=>setV(e.target.value)} onBlur={save}/>}</label>}
function Todo({title,k,day,put,check}:{title:string;k:'todo'|'dont';day:Day;put:(p:Partial<Day>)=>void;check?:boolean}){const a=day[k]
const w=(n:Item[])=>put({[k]:n})
return<section className="card"><h2>{title}</h2>{a.map((x,i)=><div key={i} className={'it'+(x.d?' dn':'')}>
{check&&<input type="checkbox" checked={!!x.d} onChange={e=>w(a.map((y,j)=>j===i?{...y,d:e.target.checked}:y))}/>}<span>{x.t}</span><button className="l" onClick={()=>w(a.filter((_,j)=>j!==i))}>✕</button></div>)}
<Add ph="اكتب وأضف" on={t=>{if(a.length<3||confirm('الحد المقترح ٣. تضيف برضه؟'))w([...a,{t}])}}/></section>}
function DayView(){const[date,setDate]=useState(today());const[k,setK]=useState(0);const[pk,setPk]=useState(false)
const day=useLiveQuery(async()=>(await db.days.get(date))??emptyDay(date),[date])
const fears=useLiveQuery(()=>db.entries.where('kind').equals('fears').filter(e=>!!e.ref).toArray(),[])
const fp=fears&&fears.length?fears[Number(date.replace(/-/g,''))%fears.length]:null
if(!day)return null
const put=(p:Partial<Day>)=>db.days.put({...day,...p})
return<div key={date+k}><h1>يوميتي</h1><input type="date" value={date} onChange={e=>setDate(e.target.value||today())}/>
<section className="card gold"><h2>آية اليوم</h2><button onClick={()=>setPk(!pk)}>{pk?'إغلاق':'اختيار من الكتاب'}</button>{pk&&<BiblePicker onPick={async(ref,verse)=>{await put({ref,verse});setPk(false);setK(k+1)}}/>}<Txt label="المرجع" k="ref" one day={day} put={put}/><Txt label="النص" k="verse" day={day} put={put}/></section>
{fp&&<section className="card"><h2>لو الخوف جالك: {fp.text}</h2><p>{fp.ref}: {fp.ptext}</p><button onClick={async()=>{await put({fromGod:fp.ref+': '+fp.ptext});setK(k+1)}}>خدها كوعد النهاردة</button></section>}<Todo title="أعمل النهاردة" k="todo" check day={day} put={put}/><Todo title="ما أعملش النهاردة" k="dont" day={day} put={put}/>
<section className="card"><h2>الصبح</h2><Txt label="صلاتي" k="prayer" day={day} put={put}/><Txt label="وعدي للرب" k="toGod" day={day} put={put}/></section>
<section className="card gold"><h2>الليل</h2><Txt label="وعد الرب لي" k="fromGod" day={day} put={put}/>
<label>وفيت بوعدي؟<select value={day.kept} onChange={e=>put({kept:e.target.value as Day['kept']})}><option value="">—</option><option value="y">وفيت</option><option value="p">جزئيًا</option><option value="n">لم أفِ</option></select></label>
<Txt label="٣ حاجات أشكر عليها" k="thanks" day={day} put={put}/><Txt label="ملاحظة" k="note" day={day} put={put}/></section></div>}
const secs:[Kind,string][]=[['dreams','أحلامي'],['fears','مخاوفي'],['wishes','أمنياتي'],['taboos','محذوراتي']]
function Inp({v,on}:{v?:string;on:(s:string)=>void}){const[x,setX]=useState(v??'');return<input value={x} onChange={e=>setX(e.target.value)} onBlur={()=>on(x)}/>}
function Library(){const all=useLiveQuery(()=>db.entries.toArray(),[]);const[pf,setPf]=useState<number|null>(null);if(!all)return null
const del=(id:number)=>db.entries.delete(id)
return<div><h1>المكتبة</h1>{secs.map(([k,t])=><section className="card" key={k}><h2>{t}</h2>{all.filter(e=>e.kind===k).map(e=><div key={e.id}><div className="it"><span>{e.text}</span>{k==='fears'&&<button className="l" onClick={()=>setPf(pf===e.id?null:e.id!)}>وعد</button>}<button className="l" onClick={()=>del(e.id!)}>✕</button></div>{e.ref&&<p className="m">{e.ref}: {e.ptext}</p>}{pf===e.id&&<BiblePicker onPick={async(ref,ptext)=>{await db.entries.update(e.id!,{ref,ptext});setPf(null)}}/>}</div>)}<Add ph="أضف" on={text=>db.entries.add({kind:k,text})}/></section>)}
<section className="card gold"><h2>أهدافي ومعوقاتها</h2>{all.filter(e=>e.kind==='goal').map(g=><div className="card" key={g.id}><b>{g.text}</b><button className="l" onClick={async()=>{await db.entries.where('parent').equals(g.id!).delete();del(g.id!)}}>✕</button>
{all.filter(o=>o.parent===g.id).map(o=><div className="it" key={o.id}><span>معوق: {o.text}</span><button className="l" onClick={()=>del(o.id!)}>✕</button></div>)}
<Add ph="أضف معوقًا" on={text=>db.entries.add({kind:'obstacle',text,parent:g.id})}/>
<label>أصغر خطوة جاية<Inp v={g.step} on={step=>db.entries.update(g.id!,{step})}/></label><label>آية/وعد متعلق<Inp v={g.verse} on={verse=>db.entries.update(g.id!,{verse})}/></label></div>)}
<Add ph="هدف جديد" on={text=>db.entries.add({kind:'goal',text})}/></section></div>}
function History(){const ds=useLiveQuery(()=>db.days.orderBy('date').reverse().toArray(),[]);const pr=useLiveQuery(()=>db.entries.where('kind').equals('prayer').toArray(),[]);const kt={y:'وفيت',p:'جزئيًا',n:'لم أفِ','':''}
const days=ds??[];const c=(k:string)=>days.filter(d=>d.kept===k).length;const tot=c('y')+c('p')+c('n')
const rows=days.filter(d=>d.toGod||d.fromGod||d.prayer);const P=pr??[]
const ans=async(e:Entry)=>{const n=prompt('ملاحظة عن الاستجابة (اختياري)');if(n!==null)await db.entries.update(e.id!,{ans:today(),note:n})}
return<div><h1>السجل</h1>
<section className="card gold"><h2>وعودي</h2>{tot?<p>وفيت {c('y')} — جزئيًا {c('p')} — لم أفِ {c('n')} (من {tot} يوم)</p>:<p className="m">سجّل وفاءك بالليل وهتظهر الأرقام هنا.</p>}</section>
<section className="card"><h2>أرشيف الصلوات</h2>{[...P.filter(e=>!e.ans),...P.filter(e=>e.ans)].map(e=><div key={e.id}><div className={'it'+(e.ans?' dn':'')}><span>{e.text}</span>{e.ans?<button className="l" onClick={()=>db.entries.update(e.id!,{ans:undefined,note:undefined})}>إعادة فتح</button>:<button className="l" onClick={()=>ans(e)}>استُجيبت</button>}<button className="l" onClick={()=>db.entries.delete(e.id!)}>✕</button></div>{e.ans&&<p className="m">استُجيبت {e.ans}{e.note&&' — '+e.note}</p>}</div>)}
<Add ph="صلاة جديدة" on={text=>db.entries.add({kind:'prayer',text})}/></section>
{rows.length?rows.map(d=><section className="card" key={d.date}><b>{d.date}{d.kept&&' — '+kt[d.kept]}</b>{d.toGod&&<p>وعدي: {d.toGod}</p>}{d.fromGod&&<p>وعده: {d.fromGod}</p>}{d.prayer&&<p className="m">صلاة: {d.prayer}</p>}</section>):<p className="m">لسه مفيش أيام مسجلة.</p>}</div>}
function Review(){const[n,setN]=useState(7)
const ds=useLiveQuery(()=>db.days.toArray(),[]);const pr=useLiveQuery(()=>db.entries.where('kind').equals('prayer').toArray(),[])
const from=new Date(Date.now()-n*864e5).toLocaleDateString('en-CA')
const R=(ds??[]).filter(d=>d.date>from&&d.date<=today()).sort((a,b)=>b.date.localeCompare(a.date))
const todo=R.flatMap(d=>d.todo);const done=todo.filter(x=>x.d).length
const cnt=new Map<string,number>();R.flatMap(d=>d.dont).forEach(x=>cnt.set(x.t,(cnt.get(x.t)||0)+1))
const top=[...cnt].sort((a,b)=>b[1]-a[1]).slice(0,3)
const k=(v:string)=>R.filter(d=>d.kept===v).length
const th=R.filter(d=>d.thanks.trim()).slice(0,3)
const ap=(pr??[]).filter(e=>e.ans&&e.ans>from)
return<div><h1>مراجعة</h1><div className="row"><button onClick={()=>setN(7)} className={n===7?'':'l'}>آخر ٧ أيام</button><button onClick={()=>setN(30)} className={n===30?'':'l'}>آخر ٣٠ يوم</button></div>
<section className="card"><h2>الفترة</h2><p>أيام فيها تسجيل: {R.filter(d=>d.toGod||d.fromGod||d.prayer||d.todo.length||d.thanks).length} من {n}</p>
<p>وعودي: وفيت {k('y')} — جزئيًا {k('p')} — لم أفِ {k('n')}</p>{todo.length>0&&<p>اللي عملته من قايمة «أعمل»: {done} من {todo.length}</p>}</section>
<section className="card"><h2>«ما أعملش» الأكتر تكرارًا</h2>{top.length?top.map(([t,c])=><div className="it" key={t}><span>{t}</span><span className="m">{c} يوم</span></div>):<p className="m">لا بيانات في الفترة دي.</p>}</section>
<section className="card gold"><h2>من شكري</h2>{th.length?th.map(d=><p key={d.date}><span className="m">{d.date}</span> {d.thanks}</p>):<p className="m">لا بيانات في الفترة دي.</p>}</section>
<section className="card"><h2>صلوات استُجيبت</h2>{ap.length?ap.map(e=><p key={e.id}>{e.text}{e.note&&' — '+e.note}</p>):<p className="m">لا شيء في الفترة دي.</p>}</section></div>}
function Settings({reload}:{reload:()=>void}){const f=useRef<HTMLInputElement>(null);const[b,setB]=useState(bioOn());const[rm,setRm]=useState(getRem())
const dl=async(pw?:string)=>{try{await saveFile('yawmiyati-'+today()+(pw?'.enc':'')+'.json',await exportAll(pw))}catch(e){if(!String(e).toLowerCase().includes('cancel'))alert('تعذر التصدير')}}
return<div><h1>إعدادات</h1><section className="card"><h2>القفل</h2><div className="row"><button onClick={async()=>{const p=prompt('PIN جديد (فاضي لإلغاء القفل)');if(p===null)return;if(p)localStorage.setItem(PIN,await sha(p));else{localStorage.removeItem(PIN);bioOff();setB(false)}}}>تغيير الـPIN</button>
{bioSupported()&&localStorage.getItem(PIN)&&<button onClick={async()=>{if(b){bioOff();setB(false)}else if(await bioEnroll().catch(()=>false))setB(true);else alert('تعذر تفعيل البصمة')}}>{b?'إيقاف البصمة':'تفعيل البصمة'}</button>}</div><p className="m">القفل التلقائي بعد دقيقة من ترك التطبيق.</p></section>
{native()&&<section className="card"><h2>تذكيرات</h2><label><input type="checkbox" checked={rm.on} onChange={e=>setRm({...rm,on:e.target.checked})}/> تفعيل تذكير الصبح والليل</label><div className="row"><input type="time" value={rm.am} onChange={e=>setRm({...rm,am:e.target.value})}/><input type="time" value={rm.pm} onChange={e=>setRm({...rm,pm:e.target.value})}/></div><button onClick={async()=>alert(await applyRem(rm)?'تم الحفظ':'الإشعارات غير مسموحة من إعدادات الموبايل')}>حفظ</button></section>}
<section className="card"><h2>نسخة احتياطية</h2><div className="row"><button onClick={()=>dl()}>تصدير</button><button onClick={()=>{const p=prompt('كلمة سر للنسخة (احفظها، مفيش استرجاع)');if(p)dl(p)}}>تصدير مشفر</button><button onClick={()=>f.current?.click()}>استيراد</button>
<input ref={f} type="file" accept=".json" hidden onChange={async e=>{const t=await e.target.files?.[0]?.text();e.target.value='';if(t){try{const pw=JSON.parse(t).enc?prompt('كلمة سر النسخة')??undefined:undefined;await importAll(t,pw);reload()}catch{alert('ملف غير صالح أو كلمة سر غلط')}}}}/></div></section></div>}
export default function App(){const[tab,setTab]=useState('day');const[ok,setOk]=useState(!localStorage.getItem(PIN));const[n,setN]=useState(0)
useEffect(()=>{let h=0;const f=()=>{if(document.hidden)h=Date.now();else if(h&&localStorage.getItem(PIN)&&Date.now()-h>60000)setOk(false)};document.addEventListener('visibilitychange',f);return()=>document.removeEventListener('visibilitychange',f)},[])
if(!ok)return<main><h1>يوميتي</h1><input type="password" inputMode="numeric" placeholder="PIN" onKeyDown={async e=>{const el=e.currentTarget;if(e.key==='Enter'){if(await sha(el.value)===localStorage.getItem(PIN))setOk(true);else el.value=''}}}/>{bioOn()&&<button onClick={async()=>{if(await bioCheck())setOk(true)}}>فتح بالبصمة</button>}</main>
const T:[string,string][]=[['day','اليوم'],['lib','المكتبة'],['hist','السجل'],['rev','مراجعة'],['set','إعدادات']]
return<><main key={n}>{tab==='day'?<DayView/>:tab==='lib'?<Library/>:tab==='hist'?<History/>:tab==='rev'?<Review/>:<Settings reload={()=>setN(n+1)}/>}</main>
<nav>{T.map(([k,t])=><button key={k} className={tab===k?'on':''} onClick={()=>setTab(k)}>{t}</button>)}</nav></>}
