import{useEffect,useState}from'react'
import{BOOKS,Bible,loadBible,strip}from'./bible'
type Hit={b:number;c:number;v:number}
export default function BiblePicker({onPick}:{onPick:(ref:string,text:string)=>void}){
const[bible,setBible]=useState<Bible>();const[b,setB]=useState(18);const[c,setC]=useState(22);const[q,setQ]=useState('')
useEffect(()=>{loadBible().then(setBible).catch(()=>alert('تعذر تحميل نص الكتاب'))},[])
if(!bible)return<p className="m">جارٍ التحميل…</p>
const pick=(h:Hit)=>onPick(`${BOOKS[h.b]} ${h.c+1}: ${h.v+1}`,bible[h.b][h.c][h.v])
const term=strip(q.trim());const hits:Hit[]=[]
if(term.length>2)search:for(let i=0;i<bible.length;i++)for(let j=0;j<bible[i].length;j++)for(let k=0;k<bible[i][j].length;k++)if(strip(bible[i][j][k]).includes(term)){hits.push({b:i,c:j,v:k});if(hits.length>=30)break search}
const Row=({h}:{h:Hit})=><div className="it vs" onClick={()=>pick(h)}><span><b>{BOOKS[h.b]} {h.c+1}:{h.v+1}</b> {bible[h.b][h.c][h.v]}</span></div>
return<div><input value={q} placeholder="ابحث في الكتاب (٣ حروف على الأقل)" onChange={e=>setQ(e.target.value)}/>
{term.length>2?(hits.length?hits.map(h=><Row key={h.b+'-'+h.c+'-'+h.v} h={h}/>):<p className="m">لا نتائج</p>):<>
<div className="row"><select value={b} onChange={e=>{setB(+e.target.value);setC(0)}}>{BOOKS.map((n,i)=><option key={i} value={i}>{n}</option>)}</select>
<select value={c} onChange={e=>setC(+e.target.value)}>{bible[b].map((_,i)=><option key={i} value={i}>{i+1}</option>)}</select></div>
{bible[b][c].map((_,v)=><Row key={v} h={{b,c,v}}/>)}</>}</div>}
