import{Capacitor}from'@capacitor/core'
import{BiometricAuth}from'@aparajita/capacitor-biometric-auth'
const BK='yawmiyati.bio'
const nat=()=>Capacitor.isNativePlatform()
export const bioSupported=()=>nat()||(!!window.PublicKeyCredential&&window.isSecureContext)
export const bioOn=()=>!!localStorage.getItem(BK)
export const bioOff=()=>localStorage.removeItem(BK)
const ch=()=>crypto.getRandomValues(new Uint8Array(32)) as BufferSource
async function nativeAuth(reason:string){try{await BiometricAuth.authenticate({reason,allowDeviceCredential:false});return true}catch{return false}}
export async function bioEnroll(){
if(nat()){if(!(await BiometricAuth.checkBiometry()).isAvailable)return false;if(!(await nativeAuth('تفعيل البصمة')))return false;localStorage.setItem(BK,'native');return true}
const c=await navigator.credentials.create({publicKey:{challenge:ch(),rp:{name:'يوميتي'},user:{id:ch(),name:'me',displayName:'me'},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required'}}}) as PublicKeyCredential|null
if(!c)return false;let s='';new Uint8Array(c.rawId).forEach(x=>{s+=String.fromCharCode(x)});localStorage.setItem(BK,btoa(s));return true}
export async function bioCheck(){
if(nat())return nativeAuth('فتح يوميتي')
const id=Uint8Array.from(atob(localStorage.getItem(BK)||''),x=>x.charCodeAt(0))
try{return!!await navigator.credentials.get({publicKey:{challenge:ch(),allowCredentials:[{type:'public-key',id}],userVerification:'required'}})}catch{return false}}
