import Dexie,{Table}from'dexie'
export type Item={t:string;d?:boolean}
export interface Day{date:string;todo:Item[];dont:Item[];ref:string;verse:string;prayer:string;toGod:string;fromGod:string;kept:''|'y'|'p'|'n';thanks:string;note:string}
export type Kind='dreams'|'fears'|'wishes'|'taboos'|'goal'|'obstacle'|'prayer'
export interface Entry{id?:number;kind:Kind;text:string;parent?:number;step?:string;verse?:string;ref?:string;ptext?:string;ans?:string;note?:string}
class DB extends Dexie{days!:Table<Day,string>;entries!:Table<Entry,number>
constructor(){super('yawmiyati');this.version(1).stores({days:'date',entries:'++id,kind,parent'})}}
export const db=new DB()
export const today=()=>new Date().toLocaleDateString('en-CA')
export const emptyDay=(date:string):Day=>({date,todo:[],dont:[],ref:'',verse:'',prayer:'',toGod:'',fromGod:'',kept:'',thanks:'',note:''})
import{encrypt,decrypt,sha}from'./crypto'
export{sha}
export const exportAll=async(pw?:string)=>{const j=JSON.stringify({v:1,days:await db.days.toArray(),entries:await db.entries.toArray()});return pw?encrypt(j,pw):j}
export const importAll=async(j:string,pw?:string)=>{let o=JSON.parse(j);if(o.enc){if(!pw)throw new Error('pw');o=JSON.parse(await decrypt(o,pw))}await db.transaction('rw',db.days,db.entries,async()=>{await db.days.clear();await db.entries.clear();await db.days.bulkAdd(o.days);await db.entries.bulkAdd(o.entries)})}
