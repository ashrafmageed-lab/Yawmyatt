import{Capacitor}from'@capacitor/core'
import{Filesystem,Directory,Encoding}from'@capacitor/filesystem'
import{Share}from'@capacitor/share'
export async function saveFile(name:string,text:string){
if(Capacitor.isNativePlatform()){const r=await Filesystem.writeFile({path:name,data:text,directory:Directory.Cache,encoding:Encoding.UTF8})
await Share.share({title:name,url:r.uri,dialogTitle:'احفظ النسخة الاحتياطية'});return}
const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text]));a.download=name;a.click()}
