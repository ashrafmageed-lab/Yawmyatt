import{createRoot}from'react-dom/client'
import{Capacitor}from'@capacitor/core'
import App from'./App'
import'./styles.css'
createRoot(document.getElementById('root')!).render(<App/>)
if('serviceWorker'in navigator&&!Capacitor.isNativePlatform()&&import.meta.env.PROD)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').then(()=>navigator.serviceWorker.ready).then(()=>caches.open('yawmiyati-v1')).then(c=>c.addAll(performance.getEntriesByType('resource').map(r=>r.name).filter(u=>u.startsWith(location.origin)))).catch(()=>{}))
