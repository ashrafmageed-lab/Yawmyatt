import{Capacitor}from'@capacitor/core'
import{LocalNotifications}from'@capacitor/local-notifications'
export const native=()=>Capacitor.isNativePlatform()
const RK='yawmiyati.rem'
export type Rem={on:boolean;am:string;pm:string}
export const getRem=():Rem=>JSON.parse(localStorage.getItem(RK)||'null')||{on:false,am:'07:00',pm:'21:00'}
const hm=(t:string)=>({hour:+t.split(':')[0],minute:+t.split(':')[1]})
export async function applyRem(r:Rem){localStorage.setItem(RK,JSON.stringify(r))
await LocalNotifications.cancel({notifications:[{id:1},{id:2}]});if(!r.on)return true
const p=await LocalNotifications.requestPermissions();if(p.display!=='granted')return false
await LocalNotifications.schedule({notifications:[
{id:1,title:'يوميتي',body:'صباح الخير — خد دقيقة لصلاتك ووعدك',schedule:{on:hm(r.am),allowWhileIdle:true}},
{id:2,title:'يوميتي',body:'قبل ما تنام: سجّل وفاءك بوعدك وشكرك',schedule:{on:hm(r.pm),allowWhileIdle:true}}]});return true}
